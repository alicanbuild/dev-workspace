// src/App.tsx
import React from "react";
import { AppRouter } from "./app/router";

export function App() {
  return <AppRouter />;
}
